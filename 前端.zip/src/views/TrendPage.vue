<template>
    <div class="com-page">
        <trend></trend>
    </div>
</template>

<script setup>
import trend from '@/components/Trend.vue';
</script>

<style scoped>
</style>