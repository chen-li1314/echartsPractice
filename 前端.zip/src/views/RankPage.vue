<template>
    <div class="com-page">
        <rank></rank>
    </div>
</template>

<script setup>
import rank from "@/components/Rank.vue";
</script>

<style scoped lang="scss">

</style>