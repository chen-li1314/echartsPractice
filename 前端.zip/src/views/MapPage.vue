<template>
    <div class="com-page">
        <maps></maps>
    </div>
</template>

<script setup>
import maps from "@/components/Map.vue";
</script>

<style scoped lang="scss">

</style>