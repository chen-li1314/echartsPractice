<template>
    <div class="com-page">
        <hot></hot>
    </div>
</template>

<script setup>
import hot from "@/components/Hot.vue";
</script>

<style scoped lang="scss">

</style>