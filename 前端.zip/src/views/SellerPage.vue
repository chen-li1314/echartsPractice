<template>
    <div class="com-page">
        <seller></seller>
    </div>
</template>

<script setup>
import seller from "@/components/Seller.vue";
</script>

<style scoped lang="scss"></style>