<template>
    <div class="com-page">
        <stock></stock>
    </div>
</template>

<script setup>
import stock from "@/components/Stock.vue";
</script>

<style scoped lang="scss">

</style>